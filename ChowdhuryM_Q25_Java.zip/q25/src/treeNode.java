public class treeNode {
    treeNode left;
    treeNode right;
    int data;

    public treeNode(int data){
        this.data = data;
    }
}
